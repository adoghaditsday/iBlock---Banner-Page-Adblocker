---
name: Filter request
about: Request support for a reproducible ad placement
title: "[Filter] "
labels: filter-request
assignees: ""
---

**Page URL**

**Ad placement**
Banner / popup / native / rich media / redirect / other

**Mode tested**
Regular / Super

**Why the element is advertising rather than site content**

**Screenshot and destination domain**
