---
name: Bug report
about: Report broken page behavior or an ad-filtering issue
title: "[Bug] "
labels: bug
assignees: ""
---

**Extension version**

**Mode**
Regular / Super

**Page URL**

**What happened**

**What should have happened**

**Clean-profile reproduction steps**

**Console errors or screenshots**
